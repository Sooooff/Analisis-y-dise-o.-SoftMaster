﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftMaster
{
    internal class ReportesFacturas
    {
        private DateTime fechaDelReporte;
        private DateTime periodoCubierto;
        private int numTotalFacEmitidas;
        private int sumaFacturas;

        public DateTime FechaDelReporte { get => fechaDelReporte; set => fechaDelReporte = value; }
        public DateTime PeriodoCubierto { get => periodoCubierto; set => periodoCubierto = value; }
        public int NumTotalFacEmitidas { get => numTotalFacEmitidas; set => numTotalFacEmitidas = value; }
        public int SumaFacturas { get => sumaFacturas; set => sumaFacturas = value; }
    }
}
