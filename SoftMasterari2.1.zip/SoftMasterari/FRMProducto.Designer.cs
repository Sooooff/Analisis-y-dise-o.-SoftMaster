﻿namespace SoftMaster
{
    partial class FRMProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbCategoria = new System.Windows.Forms.TextBox();
            this.lcategoria = new System.Windows.Forms.Label();
            this.tbExistencias = new System.Windows.Forms.TextBox();
            this.tbPrecioDeVenta = new System.Windows.Forms.TextBox();
            this.tbDescripcionProducto = new System.Windows.Forms.RichTextBox();
            this.tbPrecioDeCompra = new System.Windows.Forms.TextBox();
            this.tbNombreProducto = new System.Windows.Forms.TextBox();
            this.tbCodigoProducto = new System.Windows.Forms.TextBox();
            this.lExistencias = new System.Windows.Forms.Label();
            this.lPrecioDeVenta = new System.Windows.Forms.Label();
            this.lPrecioDeCompra = new System.Windows.Forms.Label();
            this.lDescripcion = new System.Windows.Forms.Label();
            this.lnombre = new System.Windows.Forms.Label();
            this.lcodigo = new System.Windows.Forms.Label();
            this.bNuevoProducto = new System.Windows.Forms.Button();
            this.bAgregarProducto = new System.Windows.Forms.Button();
            this.bEliminarProducto = new System.Windows.Forms.Button();
            this.bActualizarProducto = new System.Windows.Forms.Button();
            this.bGuardarProducto = new System.Windows.Forms.Button();
            this.bBuscar = new System.Windows.Forms.Button();
            this.pControlesProd = new System.Windows.Forms.Panel();
            this.tbUltimoProd = new System.Windows.Forms.TextBox();
            this.tbPrimerRegistroProd = new System.Windows.Forms.TextBox();
            this.ldeProd = new System.Windows.Forms.Label();
            this.lRegistroProd = new System.Windows.Forms.Label();
            this.bSiguienteProd = new System.Windows.Forms.Button();
            this.bUltimoProd = new System.Windows.Forms.Button();
            this.bAnteriorProd = new System.Windows.Forms.Button();
            this.bPrimeroProd = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.pControlesProd.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbProveedor);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tbCategoria);
            this.groupBox1.Controls.Add(this.lcategoria);
            this.groupBox1.Controls.Add(this.tbExistencias);
            this.groupBox1.Controls.Add(this.tbPrecioDeVenta);
            this.groupBox1.Controls.Add(this.tbDescripcionProducto);
            this.groupBox1.Controls.Add(this.tbPrecioDeCompra);
            this.groupBox1.Controls.Add(this.tbNombreProducto);
            this.groupBox1.Controls.Add(this.tbCodigoProducto);
            this.groupBox1.Controls.Add(this.lExistencias);
            this.groupBox1.Controls.Add(this.lPrecioDeVenta);
            this.groupBox1.Controls.Add(this.lPrecioDeCompra);
            this.groupBox1.Controls.Add(this.lDescripcion);
            this.groupBox1.Controls.Add(this.lnombre);
            this.groupBox1.Controls.Add(this.lcodigo);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(20, 33);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(537, 292);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos del Producto";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // tbProveedor
            // 
            this.tbProveedor.Location = new System.Drawing.Point(83, 232);
            this.tbProveedor.Margin = new System.Windows.Forms.Padding(2);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(204, 24);
            this.tbProveedor.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 232);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 15);
            this.label2.TabIndex = 19;
            this.label2.Text = "Proveedor:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(314, 140);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 18;
            // 
            // tbCategoria
            // 
            this.tbCategoria.Location = new System.Drawing.Point(83, 193);
            this.tbCategoria.Margin = new System.Windows.Forms.Padding(2);
            this.tbCategoria.Name = "tbCategoria";
            this.tbCategoria.Size = new System.Drawing.Size(204, 24);
            this.tbCategoria.TabIndex = 17;
            this.tbCategoria.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // lcategoria
            // 
            this.lcategoria.AutoSize = true;
            this.lcategoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lcategoria.Location = new System.Drawing.Point(22, 193);
            this.lcategoria.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lcategoria.Name = "lcategoria";
            this.lcategoria.Size = new System.Drawing.Size(63, 15);
            this.lcategoria.TabIndex = 16;
            this.lcategoria.Text = "Categoria:";
            // 
            // tbExistencias
            // 
            this.tbExistencias.Location = new System.Drawing.Point(383, 101);
            this.tbExistencias.Margin = new System.Windows.Forms.Padding(2);
            this.tbExistencias.Name = "tbExistencias";
            this.tbExistencias.Size = new System.Drawing.Size(135, 24);
            this.tbExistencias.TabIndex = 15;
            // 
            // tbPrecioDeVenta
            // 
            this.tbPrecioDeVenta.Location = new System.Drawing.Point(404, 70);
            this.tbPrecioDeVenta.Margin = new System.Windows.Forms.Padding(2);
            this.tbPrecioDeVenta.Name = "tbPrecioDeVenta";
            this.tbPrecioDeVenta.Size = new System.Drawing.Size(115, 24);
            this.tbPrecioDeVenta.TabIndex = 14;
            // 
            // tbDescripcionProducto
            // 
            this.tbDescripcionProducto.Location = new System.Drawing.Point(94, 104);
            this.tbDescripcionProducto.Margin = new System.Windows.Forms.Padding(2);
            this.tbDescripcionProducto.Name = "tbDescripcionProducto";
            this.tbDescripcionProducto.Size = new System.Drawing.Size(193, 79);
            this.tbDescripcionProducto.TabIndex = 13;
            this.tbDescripcionProducto.Text = "";
            this.tbDescripcionProducto.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // tbPrecioDeCompra
            // 
            this.tbPrecioDeCompra.Location = new System.Drawing.Point(416, 38);
            this.tbPrecioDeCompra.Margin = new System.Windows.Forms.Padding(2);
            this.tbPrecioDeCompra.Name = "tbPrecioDeCompra";
            this.tbPrecioDeCompra.Size = new System.Drawing.Size(103, 24);
            this.tbPrecioDeCompra.TabIndex = 12;
            // 
            // tbNombreProducto
            // 
            this.tbNombreProducto.Location = new System.Drawing.Point(71, 65);
            this.tbNombreProducto.Margin = new System.Windows.Forms.Padding(2);
            this.tbNombreProducto.Name = "tbNombreProducto";
            this.tbNombreProducto.Size = new System.Drawing.Size(216, 24);
            this.tbNombreProducto.TabIndex = 11;
            // 
            // tbCodigoProducto
            // 
            this.tbCodigoProducto.Location = new System.Drawing.Point(71, 35);
            this.tbCodigoProducto.Margin = new System.Windows.Forms.Padding(2);
            this.tbCodigoProducto.Name = "tbCodigoProducto";
            this.tbCodigoProducto.Size = new System.Drawing.Size(216, 24);
            this.tbCodigoProducto.TabIndex = 10;
            // 
            // lExistencias
            // 
            this.lExistencias.AutoSize = true;
            this.lExistencias.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lExistencias.Location = new System.Drawing.Point(314, 107);
            this.lExistencias.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lExistencias.Name = "lExistencias";
            this.lExistencias.Size = new System.Drawing.Size(72, 15);
            this.lExistencias.TabIndex = 9;
            this.lExistencias.Text = "Existencias:";
            // 
            // lPrecioDeVenta
            // 
            this.lPrecioDeVenta.AutoSize = true;
            this.lPrecioDeVenta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lPrecioDeVenta.Location = new System.Drawing.Point(314, 73);
            this.lPrecioDeVenta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lPrecioDeVenta.Name = "lPrecioDeVenta";
            this.lPrecioDeVenta.Size = new System.Drawing.Size(94, 15);
            this.lPrecioDeVenta.TabIndex = 8;
            this.lPrecioDeVenta.Text = "Precio de venta:";
            // 
            // lPrecioDeCompra
            // 
            this.lPrecioDeCompra.AutoSize = true;
            this.lPrecioDeCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lPrecioDeCompra.Location = new System.Drawing.Point(314, 38);
            this.lPrecioDeCompra.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lPrecioDeCompra.Name = "lPrecioDeCompra";
            this.lPrecioDeCompra.Size = new System.Drawing.Size(107, 15);
            this.lPrecioDeCompra.TabIndex = 7;
            this.lPrecioDeCompra.Text = "Precio de compra:";
            // 
            // lDescripcion
            // 
            this.lDescripcion.AutoSize = true;
            this.lDescripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lDescripcion.Location = new System.Drawing.Point(22, 104);
            this.lDescripcion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lDescripcion.Name = "lDescripcion";
            this.lDescripcion.Size = new System.Drawing.Size(75, 15);
            this.lDescripcion.TabIndex = 1;
            this.lDescripcion.Text = "Descripción:";
            // 
            // lnombre
            // 
            this.lnombre.AutoSize = true;
            this.lnombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnombre.Location = new System.Drawing.Point(22, 68);
            this.lnombre.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lnombre.Name = "lnombre";
            this.lnombre.Size = new System.Drawing.Size(55, 15);
            this.lnombre.TabIndex = 6;
            this.lnombre.Text = "Nombre:";
            // 
            // lcodigo
            // 
            this.lcodigo.AutoSize = true;
            this.lcodigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lcodigo.Location = new System.Drawing.Point(22, 38);
            this.lcodigo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lcodigo.Name = "lcodigo";
            this.lcodigo.Size = new System.Drawing.Size(49, 15);
            this.lcodigo.TabIndex = 0;
            this.lcodigo.Text = "Código:";
            // 
            // bNuevoProducto
            // 
            this.bNuevoProducto.Location = new System.Drawing.Point(584, 44);
            this.bNuevoProducto.Margin = new System.Windows.Forms.Padding(2);
            this.bNuevoProducto.Name = "bNuevoProducto";
            this.bNuevoProducto.Size = new System.Drawing.Size(72, 30);
            this.bNuevoProducto.TabIndex = 1;
            this.bNuevoProducto.Text = "Nuevo";
            this.bNuevoProducto.UseVisualStyleBackColor = true;
            this.bNuevoProducto.Click += new System.EventHandler(this.bNuevoProducto_Click);
            // 
            // bAgregarProducto
            // 
            this.bAgregarProducto.Location = new System.Drawing.Point(584, 79);
            this.bAgregarProducto.Margin = new System.Windows.Forms.Padding(2);
            this.bAgregarProducto.Name = "bAgregarProducto";
            this.bAgregarProducto.Size = new System.Drawing.Size(72, 30);
            this.bAgregarProducto.TabIndex = 2;
            this.bAgregarProducto.Text = "Agregar";
            this.bAgregarProducto.UseVisualStyleBackColor = true;
            this.bAgregarProducto.Click += new System.EventHandler(this.bAgregarProducto_Click);
            // 
            // bEliminarProducto
            // 
            this.bEliminarProducto.Location = new System.Drawing.Point(584, 114);
            this.bEliminarProducto.Margin = new System.Windows.Forms.Padding(2);
            this.bEliminarProducto.Name = "bEliminarProducto";
            this.bEliminarProducto.Size = new System.Drawing.Size(72, 30);
            this.bEliminarProducto.TabIndex = 3;
            this.bEliminarProducto.Text = "Eliminar";
            this.bEliminarProducto.UseVisualStyleBackColor = true;
            this.bEliminarProducto.Click += new System.EventHandler(this.bEliminarProducto_Click);
            // 
            // bActualizarProducto
            // 
            this.bActualizarProducto.Location = new System.Drawing.Point(584, 149);
            this.bActualizarProducto.Margin = new System.Windows.Forms.Padding(2);
            this.bActualizarProducto.Name = "bActualizarProducto";
            this.bActualizarProducto.Size = new System.Drawing.Size(72, 30);
            this.bActualizarProducto.TabIndex = 4;
            this.bActualizarProducto.Text = "Actualizar";
            this.bActualizarProducto.UseVisualStyleBackColor = true;
            this.bActualizarProducto.Click += new System.EventHandler(this.bActualizarProducto_Click);
            // 
            // bGuardarProducto
            // 
            this.bGuardarProducto.Location = new System.Drawing.Point(584, 184);
            this.bGuardarProducto.Margin = new System.Windows.Forms.Padding(2);
            this.bGuardarProducto.Name = "bGuardarProducto";
            this.bGuardarProducto.Size = new System.Drawing.Size(72, 30);
            this.bGuardarProducto.TabIndex = 5;
            this.bGuardarProducto.Text = "Guardar";
            this.bGuardarProducto.UseVisualStyleBackColor = true;
            this.bGuardarProducto.Click += new System.EventHandler(this.bGuardarProducto_Click);
            // 
            // bBuscar
            // 
            this.bBuscar.Location = new System.Drawing.Point(584, 219);
            this.bBuscar.Margin = new System.Windows.Forms.Padding(2);
            this.bBuscar.Name = "bBuscar";
            this.bBuscar.Size = new System.Drawing.Size(72, 30);
            this.bBuscar.TabIndex = 6;
            this.bBuscar.Text = "Buscar";
            this.bBuscar.UseVisualStyleBackColor = true;
            this.bBuscar.Click += new System.EventHandler(this.bBuscar_Click);
            // 
            // pControlesProd
            // 
            this.pControlesProd.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pControlesProd.Controls.Add(this.tbUltimoProd);
            this.pControlesProd.Controls.Add(this.tbPrimerRegistroProd);
            this.pControlesProd.Controls.Add(this.ldeProd);
            this.pControlesProd.Controls.Add(this.lRegistroProd);
            this.pControlesProd.Controls.Add(this.bSiguienteProd);
            this.pControlesProd.Controls.Add(this.bUltimoProd);
            this.pControlesProd.Controls.Add(this.bAnteriorProd);
            this.pControlesProd.Controls.Add(this.bPrimeroProd);
            this.pControlesProd.Location = new System.Drawing.Point(126, 329);
            this.pControlesProd.Margin = new System.Windows.Forms.Padding(2);
            this.pControlesProd.Name = "pControlesProd";
            this.pControlesProd.Size = new System.Drawing.Size(353, 37);
            this.pControlesProd.TabIndex = 21;
            // 
            // tbUltimoProd
            // 
            this.tbUltimoProd.Location = new System.Drawing.Point(216, 11);
            this.tbUltimoProd.Margin = new System.Windows.Forms.Padding(2);
            this.tbUltimoProd.Name = "tbUltimoProd";
            this.tbUltimoProd.Size = new System.Drawing.Size(49, 20);
            this.tbUltimoProd.TabIndex = 25;
            // 
            // tbPrimerRegistroProd
            // 
            this.tbPrimerRegistroProd.Location = new System.Drawing.Point(141, 11);
            this.tbPrimerRegistroProd.Margin = new System.Windows.Forms.Padding(2);
            this.tbPrimerRegistroProd.Name = "tbPrimerRegistroProd";
            this.tbPrimerRegistroProd.Size = new System.Drawing.Size(49, 20);
            this.tbPrimerRegistroProd.TabIndex = 21;
            // 
            // ldeProd
            // 
            this.ldeProd.AutoSize = true;
            this.ldeProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ldeProd.Location = new System.Drawing.Point(194, 11);
            this.ldeProd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ldeProd.Name = "ldeProd";
            this.ldeProd.Size = new System.Drawing.Size(21, 15);
            this.ldeProd.TabIndex = 24;
            this.ldeProd.Text = "de";
            // 
            // lRegistroProd
            // 
            this.lRegistroProd.AutoSize = true;
            this.lRegistroProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lRegistroProd.Location = new System.Drawing.Point(88, 11);
            this.lRegistroProd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lRegistroProd.Name = "lRegistroProd";
            this.lRegistroProd.Size = new System.Drawing.Size(53, 15);
            this.lRegistroProd.TabIndex = 21;
            this.lRegistroProd.Text = "Registro";
            // 
            // bSiguienteProd
            // 
            this.bSiguienteProd.Location = new System.Drawing.Point(277, 2);
            this.bSiguienteProd.Margin = new System.Windows.Forms.Padding(2);
            this.bSiguienteProd.Name = "bSiguienteProd";
            this.bSiguienteProd.Size = new System.Drawing.Size(34, 32);
            this.bSiguienteProd.TabIndex = 23;
            this.bSiguienteProd.Text = ">";
            this.bSiguienteProd.UseVisualStyleBackColor = true;
            this.bSiguienteProd.Click += new System.EventHandler(this.bSiguienteProd_Click);
            // 
            // bUltimoProd
            // 
            this.bUltimoProd.Location = new System.Drawing.Point(316, 2);
            this.bUltimoProd.Margin = new System.Windows.Forms.Padding(2);
            this.bUltimoProd.Name = "bUltimoProd";
            this.bUltimoProd.Size = new System.Drawing.Size(34, 32);
            this.bUltimoProd.TabIndex = 23;
            this.bUltimoProd.Text = ">>";
            this.bUltimoProd.UseVisualStyleBackColor = true;
            this.bUltimoProd.Click += new System.EventHandler(this.bUltimoProd_Click);
            // 
            // bAnteriorProd
            // 
            this.bAnteriorProd.Location = new System.Drawing.Point(41, 2);
            this.bAnteriorProd.Margin = new System.Windows.Forms.Padding(2);
            this.bAnteriorProd.Name = "bAnteriorProd";
            this.bAnteriorProd.Size = new System.Drawing.Size(34, 32);
            this.bAnteriorProd.TabIndex = 22;
            this.bAnteriorProd.Text = "<";
            this.bAnteriorProd.UseVisualStyleBackColor = true;
            this.bAnteriorProd.Click += new System.EventHandler(this.bAnteriorProd_Click);
            // 
            // bPrimeroProd
            // 
            this.bPrimeroProd.Location = new System.Drawing.Point(2, 2);
            this.bPrimeroProd.Margin = new System.Windows.Forms.Padding(2);
            this.bPrimeroProd.Name = "bPrimeroProd";
            this.bPrimeroProd.Size = new System.Drawing.Size(34, 32);
            this.bPrimeroProd.TabIndex = 21;
            this.bPrimeroProd.Text = "<<";
            this.bPrimeroProd.UseVisualStyleBackColor = true;
            this.bPrimeroProd.Click += new System.EventHandler(this.bPrimeroProd_Click);
            // 
            // FRMProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 403);
            this.Controls.Add(this.pControlesProd);
            this.Controls.Add(this.bBuscar);
            this.Controls.Add(this.bGuardarProducto);
            this.Controls.Add(this.bActualizarProducto);
            this.Controls.Add(this.bEliminarProducto);
            this.Controls.Add(this.bAgregarProducto);
            this.Controls.Add(this.bNuevoProducto);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FRMProducto";
            this.Text = "SoftMaster | Gestion de Productos";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pControlesProd.ResumeLayout(false);
            this.pControlesProd.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lcodigo;
        private System.Windows.Forms.Label lnombre;
        private System.Windows.Forms.Label lDescripcion;
        private System.Windows.Forms.Label lExistencias;
        private System.Windows.Forms.Label lPrecioDeVenta;
        private System.Windows.Forms.Label lPrecioDeCompra;
        private System.Windows.Forms.TextBox tbPrecioDeCompra;
        private System.Windows.Forms.TextBox tbNombreProducto;
        private System.Windows.Forms.TextBox tbCodigoProducto;
        private System.Windows.Forms.RichTextBox tbDescripcionProducto;
        private System.Windows.Forms.TextBox tbPrecioDeVenta;
        private System.Windows.Forms.Label lcategoria;
        private System.Windows.Forms.TextBox tbExistencias;
        private System.Windows.Forms.TextBox tbCategoria;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bNuevoProducto;
        private System.Windows.Forms.Button bAgregarProducto;
        private System.Windows.Forms.Button bEliminarProducto;
        private System.Windows.Forms.Button bActualizarProducto;
        private System.Windows.Forms.Button bGuardarProducto;
        private System.Windows.Forms.Button bBuscar;
        private System.Windows.Forms.Panel pControlesProd;
        private System.Windows.Forms.TextBox tbUltimoProd;
        private System.Windows.Forms.TextBox tbPrimerRegistroProd;
        private System.Windows.Forms.Label ldeProd;
        private System.Windows.Forms.Label lRegistroProd;
        private System.Windows.Forms.Button bSiguienteProd;
        private System.Windows.Forms.Button bUltimoProd;
        private System.Windows.Forms.Button bAnteriorProd;
        private System.Windows.Forms.Button bPrimeroProd;
    }
}