﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftMaster
{
    public partial class FRMClientes : Form
    {


        private TCliente tablaClien = TCliente.getInstancia();

        private static FRMClientes instance;
        private FRMClientes()
        {
            InitializeComponent();
        }

        //funcion para que solo de muestre 1 vez el formulario
        public static FRMClientes getInstance()
        {
            if (instance == null || instance.IsDisposed)
                instance = new FRMClientes();
            return instance;
        }

        private void mostrar(Cliente cli)
        {
            if (cli != null)
            {
                this.tbCodigoCliente.Text = cli.CodCliente;
                this.tbNombreCliente.Text = cli.NombreCliente;
                this.tbApellido.Text = cli.Apellido;
                this.tbEmpresa.Text = cli.Empresa;
                this.tbPuestoEnLaEmpresa.Text = cli.PuestoEmpresa;
                this.tbTelefono.Text = cli.Telefono;
                this.tbClasificacion.Text = cli.Clasificacion;

            }
            else
            {
                this.tbCodigoCliente.Text = "";
                this.tbNombreCliente.Text = "";
                this.tbApellido.Text = "";
                this.tbEmpresa.Text = "";
                this.tbPuestoEnLaEmpresa.Text = "";
                this.tbTelefono.Text = "";
                this.tbClasificacion.Text = "";
                MessageBox.Show("No hay registro a mostrar",
                    "Registro de clientes", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            this.actualizarPanelNavegacion();
        }

        private void buscarCliente(string codigo)
        {
            // Busca el cliente en la tabla
            Cliente cli = tablaClien.buscarClientePorCodigo(codigo);

            // Verifica si se encontró el cliente y actualiza el formulario
            if (cli != null)
            {
                mostrar(cli);
            }
            else
            {
                MessageBox.Show("No se encontró un cliente con el código proporcionado.",
                    "Búsqueda de clientes",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }




        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lEmpresa_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void bGuardar_Click(object sender, EventArgs e)
        {
            int success;
            int resp = (int)MessageBox.Show("Esta seguro que desea guardar los datos permanentemente?",
                   "Registro de clientes",
                   MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resp == 6)
            {
                success = tablaClien.guardar();
                if (success != 0)
                {
                    MessageBox.Show("los datos se guardaron exitosamente", "registro del cliente", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    MessageBox.Show("Error al guardar los datos", "registro del cliente", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void actualizarPanelNavegacion()
        {
            this.tbCodigoCliente.Enabled = false;
            this.tbPrimerRegistro.Enabled = false;
            this.tbUltimo.Enabled = false;
            if (tablaClien.verificarVacio() == true)
                this.tbPrimerRegistro.Text = "0";
            else
                this.tbPrimerRegistro.Text = tablaClien.buscarRegistro(this.tbCodigoCliente.Text + 1).ToString();
            this.tbUltimo.Text = tablaClien.cantidadRegistros().ToString();

        }

        private void bAgregar_Click(object sender, EventArgs e)
        {
            if (tablaClien.verificarExistencia(this.tbCodigoCliente.Text) == false)
            {
                Cliente cli = new Cliente();

                cli.CodCliente = this.tbCodigoCliente.Text;
                cli.NombreCliente = this.tbNombreCliente.Text;
                cli.Apellido = this.tbApellido.Text;
                cli.Empresa = this.tbEmpresa.Text;
                cli.PuestoEmpresa = this.tbPuestoEnLaEmpresa.Text;
                cli.Telefono = this.tbTelefono.Text;
                cli.Clasificacion = this.tbClasificacion.Text;
                tablaClien.agregarCliente(cli);
                this.actualizarPanelNavegacion();
            }
            else
            {
                MessageBox.Show("Ya existe un cliente con el Codigo indicado", "Registro de clientes", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tbPrimerRegistro_TextChanged(object sender, EventArgs e)
        {

        }

        private void bNuevo_Click(object sender, EventArgs e)
        {
            this.tbCodigoCliente.Enabled = true;
            this.tbCodigoCliente.Text = "";
            this.tbNombreCliente.Text = "";
            this.tbApellido.Text = "";
            this.tbEmpresa.Text = "";
            this.tbPuestoEnLaEmpresa.Text = "";
            this.tbTelefono.Text = "";
            this.tbClasificacion.Text = "";
            this.tbCodigoCliente.Focus();
            this.tbPrimerRegistro.Text = "";
            this.tbUltimo.Text = "";
        }

        private void bEliminar_Click(object sender, EventArgs e)
        {
            int resp;
            if (this.tbCodigoCliente.Text != "")
            {
                resp = (int)MessageBox.Show("¿Esta seguro que desea eliminar el registro?",
                    "Registro de clientes",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (resp == 6)
                {
                    int index = tablaClien.buscarRegistro(this.tbCodigoCliente.Text);
                    tablaClien.eliminarRegistro(index);
                    if (tablaClien.cantidadRegistros() >= 1)
                    {
                        mostrar(tablaClien.devolverPrimero());
                    }
                    else
                    {
                        this.tbCodigoCliente.Text = "";
                        this.tbNombreCliente.Text = "";
                        this.tbApellido.Text = "";
                        this.tbEmpresa.Text = "";
                        this.tbPuestoEnLaEmpresa.Text = "";
                        this.tbTelefono.Text = "";
                        this.tbClasificacion.Text = "";
                        mostrar(null);
                    }
                }
            }
        }

        private void bActualizar_Click(object sender, EventArgs e)
        {
            int resp;
            if (this.tbCodigoCliente.Text != "")
            {
                resp = (int)MessageBox.Show("¿Esta seguro que desea actualizar el registro?",
                    "Registro de clientes",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (resp == 6)
                {
                    int index = tablaClien.buscarRegistro(this.tbCodigoCliente.Text);
                    Cliente cli = tablaClien.buscarRegistro(index);
                    cli.NombreCliente = this.tbNombreCliente.Text;
                    cli.Apellido = this.tbApellido.Text;
                    cli.Empresa = this.tbEmpresa.Text;
                    cli.PuestoEmpresa = this.tbPuestoEnLaEmpresa.Text;
                    cli.Telefono = this.tbTelefono.Text;
                    cli.Clasificacion = this.tbClasificacion.Text;

                }
            }
        }

        private void bBuscar_Click(object sender, EventArgs e)
        {
            string codigo = this.tbCodigoCliente.Text;

            if (!string.IsNullOrEmpty(codigo))
            {
                buscarCliente(codigo);
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un código para buscar.",
                    "Búsqueda de clientes",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }
    }
}
