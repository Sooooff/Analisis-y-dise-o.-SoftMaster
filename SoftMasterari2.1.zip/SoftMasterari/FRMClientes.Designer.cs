﻿namespace SoftMaster
{
    partial class FRMClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lcodigo = new System.Windows.Forms.Label();
            this.tbCodigoCliente = new System.Windows.Forms.TextBox();
            this.lNombre = new System.Windows.Forms.Label();
            this.lApellido = new System.Windows.Forms.Label();
            this.lEmpresa = new System.Windows.Forms.Label();
            this.lPuestoEnLaEmpresa = new System.Windows.Forms.Label();
            this.lTelefono = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbClasificacion = new System.Windows.Forms.TextBox();
            this.tbNombreCliente = new System.Windows.Forms.TextBox();
            this.tbApellido = new System.Windows.Forms.TextBox();
            this.tbTelefono = new System.Windows.Forms.TextBox();
            this.tbEmpresa = new System.Windows.Forms.TextBox();
            this.tbPuestoEnLaEmpresa = new System.Windows.Forms.TextBox();
            this.bNuevo = new System.Windows.Forms.Button();
            this.bAgregar = new System.Windows.Forms.Button();
            this.bEliminar = new System.Windows.Forms.Button();
            this.bActualizar = new System.Windows.Forms.Button();
            this.bGuardar = new System.Windows.Forms.Button();
            this.bBuscar = new System.Windows.Forms.Button();
            this.pControlesClientes = new System.Windows.Forms.Panel();
            this.tbUltimo = new System.Windows.Forms.TextBox();
            this.tbPrimerRegistro = new System.Windows.Forms.TextBox();
            this.lde = new System.Windows.Forms.Label();
            this.lRegistro = new System.Windows.Forms.Label();
            this.bSiguiente = new System.Windows.Forms.Button();
            this.bUltimo = new System.Windows.Forms.Button();
            this.bAnterior = new System.Windows.Forms.Button();
            this.bPrimero = new System.Windows.Forms.Button();
            this.pControlesClientes.SuspendLayout();
            this.SuspendLayout();
            // 
            // lcodigo
            // 
            this.lcodigo.AutoSize = true;
            this.lcodigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lcodigo.Location = new System.Drawing.Point(40, 52);
            this.lcodigo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lcodigo.Name = "lcodigo";
            this.lcodigo.Size = new System.Drawing.Size(49, 15);
            this.lcodigo.TabIndex = 0;
            this.lcodigo.Text = "Código:";
            // 
            // tbCodigoCliente
            // 
            this.tbCodigoCliente.Location = new System.Drawing.Point(89, 52);
            this.tbCodigoCliente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbCodigoCliente.Name = "tbCodigoCliente";
            this.tbCodigoCliente.Size = new System.Drawing.Size(176, 20);
            this.tbCodigoCliente.TabIndex = 1;
            // 
            // lNombre
            // 
            this.lNombre.AutoSize = true;
            this.lNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lNombre.Location = new System.Drawing.Point(40, 105);
            this.lNombre.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lNombre.Name = "lNombre";
            this.lNombre.Size = new System.Drawing.Size(55, 15);
            this.lNombre.TabIndex = 2;
            this.lNombre.Text = "Nombre:";
            // 
            // lApellido
            // 
            this.lApellido.AutoSize = true;
            this.lApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lApellido.Location = new System.Drawing.Point(40, 132);
            this.lApellido.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lApellido.Name = "lApellido";
            this.lApellido.Size = new System.Drawing.Size(54, 15);
            this.lApellido.TabIndex = 3;
            this.lApellido.Text = "Apellido:";
            this.lApellido.Click += new System.EventHandler(this.label1_Click);
            // 
            // lEmpresa
            // 
            this.lEmpresa.AutoSize = true;
            this.lEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lEmpresa.Location = new System.Drawing.Point(40, 188);
            this.lEmpresa.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lEmpresa.Name = "lEmpresa";
            this.lEmpresa.Size = new System.Drawing.Size(60, 15);
            this.lEmpresa.TabIndex = 4;
            this.lEmpresa.Text = "Empresa:";
            this.lEmpresa.Click += new System.EventHandler(this.lEmpresa_Click);
            // 
            // lPuestoEnLaEmpresa
            // 
            this.lPuestoEnLaEmpresa.AutoSize = true;
            this.lPuestoEnLaEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lPuestoEnLaEmpresa.Location = new System.Drawing.Point(40, 216);
            this.lPuestoEnLaEmpresa.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lPuestoEnLaEmpresa.Name = "lPuestoEnLaEmpresa";
            this.lPuestoEnLaEmpresa.Size = new System.Drawing.Size(130, 15);
            this.lPuestoEnLaEmpresa.TabIndex = 5;
            this.lPuestoEnLaEmpresa.Text = "Puesto en la empresa:";
            // 
            // lTelefono
            // 
            this.lTelefono.AutoSize = true;
            this.lTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lTelefono.Location = new System.Drawing.Point(40, 160);
            this.lTelefono.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lTelefono.Name = "lTelefono";
            this.lTelefono.Size = new System.Drawing.Size(58, 15);
            this.lTelefono.TabIndex = 6;
            this.lTelefono.Text = "Telefono:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(40, 78);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Clasificación:";
            // 
            // tbClasificacion
            // 
            this.tbClasificacion.Location = new System.Drawing.Point(116, 77);
            this.tbClasificacion.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbClasificacion.Name = "tbClasificacion";
            this.tbClasificacion.Size = new System.Drawing.Size(150, 20);
            this.tbClasificacion.TabIndex = 8;
            // 
            // tbNombreCliente
            // 
            this.tbNombreCliente.Location = new System.Drawing.Point(89, 105);
            this.tbNombreCliente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbNombreCliente.Name = "tbNombreCliente";
            this.tbNombreCliente.Size = new System.Drawing.Size(176, 20);
            this.tbNombreCliente.TabIndex = 9;
            // 
            // tbApellido
            // 
            this.tbApellido.Location = new System.Drawing.Point(89, 132);
            this.tbApellido.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbApellido.Name = "tbApellido";
            this.tbApellido.Size = new System.Drawing.Size(176, 20);
            this.tbApellido.TabIndex = 10;
            // 
            // tbTelefono
            // 
            this.tbTelefono.Location = new System.Drawing.Point(97, 160);
            this.tbTelefono.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbTelefono.Name = "tbTelefono";
            this.tbTelefono.Size = new System.Drawing.Size(169, 20);
            this.tbTelefono.TabIndex = 11;
            // 
            // tbEmpresa
            // 
            this.tbEmpresa.Location = new System.Drawing.Point(97, 188);
            this.tbEmpresa.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbEmpresa.Name = "tbEmpresa";
            this.tbEmpresa.Size = new System.Drawing.Size(169, 20);
            this.tbEmpresa.TabIndex = 12;
            // 
            // tbPuestoEnLaEmpresa
            // 
            this.tbPuestoEnLaEmpresa.Location = new System.Drawing.Point(161, 216);
            this.tbPuestoEnLaEmpresa.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbPuestoEnLaEmpresa.Name = "tbPuestoEnLaEmpresa";
            this.tbPuestoEnLaEmpresa.Size = new System.Drawing.Size(104, 20);
            this.tbPuestoEnLaEmpresa.TabIndex = 13;
            // 
            // bNuevo
            // 
            this.bNuevo.Location = new System.Drawing.Point(319, 48);
            this.bNuevo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bNuevo.Name = "bNuevo";
            this.bNuevo.Size = new System.Drawing.Size(76, 27);
            this.bNuevo.TabIndex = 14;
            this.bNuevo.Text = "Nuevo";
            this.bNuevo.UseVisualStyleBackColor = true;
            this.bNuevo.Click += new System.EventHandler(this.bNuevo_Click);
            // 
            // bAgregar
            // 
            this.bAgregar.Location = new System.Drawing.Point(319, 80);
            this.bAgregar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bAgregar.Name = "bAgregar";
            this.bAgregar.Size = new System.Drawing.Size(76, 27);
            this.bAgregar.TabIndex = 15;
            this.bAgregar.Text = "Agregar";
            this.bAgregar.UseVisualStyleBackColor = true;
            this.bAgregar.Click += new System.EventHandler(this.bAgregar_Click);
            // 
            // bEliminar
            // 
            this.bEliminar.Location = new System.Drawing.Point(319, 115);
            this.bEliminar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bEliminar.Name = "bEliminar";
            this.bEliminar.Size = new System.Drawing.Size(76, 27);
            this.bEliminar.TabIndex = 16;
            this.bEliminar.Text = "Eliminar";
            this.bEliminar.UseVisualStyleBackColor = true;
            this.bEliminar.Click += new System.EventHandler(this.bEliminar_Click);
            // 
            // bActualizar
            // 
            this.bActualizar.Location = new System.Drawing.Point(319, 147);
            this.bActualizar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bActualizar.Name = "bActualizar";
            this.bActualizar.Size = new System.Drawing.Size(76, 27);
            this.bActualizar.TabIndex = 17;
            this.bActualizar.Text = "Actualizar";
            this.bActualizar.UseVisualStyleBackColor = true;
            this.bActualizar.Click += new System.EventHandler(this.bActualizar_Click);
            // 
            // bGuardar
            // 
            this.bGuardar.Location = new System.Drawing.Point(319, 179);
            this.bGuardar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bGuardar.Name = "bGuardar";
            this.bGuardar.Size = new System.Drawing.Size(76, 27);
            this.bGuardar.TabIndex = 18;
            this.bGuardar.Text = "Guardar";
            this.bGuardar.UseVisualStyleBackColor = true;
            this.bGuardar.Click += new System.EventHandler(this.bGuardar_Click);
            // 
            // bBuscar
            // 
            this.bBuscar.Location = new System.Drawing.Point(319, 211);
            this.bBuscar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bBuscar.Name = "bBuscar";
            this.bBuscar.Size = new System.Drawing.Size(76, 27);
            this.bBuscar.TabIndex = 19;
            this.bBuscar.Text = "Buscar";
            this.bBuscar.UseVisualStyleBackColor = true;
            this.bBuscar.Click += new System.EventHandler(this.bBuscar_Click);
            // 
            // pControlesClientes
            // 
            this.pControlesClientes.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pControlesClientes.Controls.Add(this.tbUltimo);
            this.pControlesClientes.Controls.Add(this.tbPrimerRegistro);
            this.pControlesClientes.Controls.Add(this.lde);
            this.pControlesClientes.Controls.Add(this.lRegistro);
            this.pControlesClientes.Controls.Add(this.bSiguiente);
            this.pControlesClientes.Controls.Add(this.bUltimo);
            this.pControlesClientes.Controls.Add(this.bAnterior);
            this.pControlesClientes.Controls.Add(this.bPrimero);
            this.pControlesClientes.Location = new System.Drawing.Point(42, 274);
            this.pControlesClientes.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pControlesClientes.Name = "pControlesClientes";
            this.pControlesClientes.Size = new System.Drawing.Size(353, 37);
            this.pControlesClientes.TabIndex = 20;
            // 
            // tbUltimo
            // 
            this.tbUltimo.Location = new System.Drawing.Point(216, 11);
            this.tbUltimo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbUltimo.Name = "tbUltimo";
            this.tbUltimo.Size = new System.Drawing.Size(49, 20);
            this.tbUltimo.TabIndex = 25;
            // 
            // tbPrimerRegistro
            // 
            this.tbPrimerRegistro.Location = new System.Drawing.Point(141, 11);
            this.tbPrimerRegistro.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbPrimerRegistro.Name = "tbPrimerRegistro";
            this.tbPrimerRegistro.Size = new System.Drawing.Size(49, 20);
            this.tbPrimerRegistro.TabIndex = 21;
            this.tbPrimerRegistro.TextChanged += new System.EventHandler(this.tbPrimerRegistro_TextChanged);
            // 
            // lde
            // 
            this.lde.AutoSize = true;
            this.lde.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lde.Location = new System.Drawing.Point(194, 11);
            this.lde.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lde.Name = "lde";
            this.lde.Size = new System.Drawing.Size(21, 15);
            this.lde.TabIndex = 24;
            this.lde.Text = "de";
            // 
            // lRegistro
            // 
            this.lRegistro.AutoSize = true;
            this.lRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lRegistro.Location = new System.Drawing.Point(88, 11);
            this.lRegistro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lRegistro.Name = "lRegistro";
            this.lRegistro.Size = new System.Drawing.Size(53, 15);
            this.lRegistro.TabIndex = 21;
            this.lRegistro.Text = "Registro";
            // 
            // bSiguiente
            // 
            this.bSiguiente.Location = new System.Drawing.Point(277, 2);
            this.bSiguiente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bSiguiente.Name = "bSiguiente";
            this.bSiguiente.Size = new System.Drawing.Size(34, 32);
            this.bSiguiente.TabIndex = 23;
            this.bSiguiente.Text = ">";
            this.bSiguiente.UseVisualStyleBackColor = true;
            this.bSiguiente.Click += new System.EventHandler(this.button2_Click);
            // 
            // bUltimo
            // 
            this.bUltimo.Location = new System.Drawing.Point(316, 2);
            this.bUltimo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bUltimo.Name = "bUltimo";
            this.bUltimo.Size = new System.Drawing.Size(34, 32);
            this.bUltimo.TabIndex = 23;
            this.bUltimo.Text = ">>";
            this.bUltimo.UseVisualStyleBackColor = true;
            // 
            // bAnterior
            // 
            this.bAnterior.Location = new System.Drawing.Point(41, 2);
            this.bAnterior.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bAnterior.Name = "bAnterior";
            this.bAnterior.Size = new System.Drawing.Size(34, 32);
            this.bAnterior.TabIndex = 22;
            this.bAnterior.Text = "<";
            this.bAnterior.UseVisualStyleBackColor = true;
            // 
            // bPrimero
            // 
            this.bPrimero.Location = new System.Drawing.Point(2, 2);
            this.bPrimero.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bPrimero.Name = "bPrimero";
            this.bPrimero.Size = new System.Drawing.Size(34, 32);
            this.bPrimero.TabIndex = 21;
            this.bPrimero.Text = "<<";
            this.bPrimero.UseVisualStyleBackColor = true;
            // 
            // FRMClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 343);
            this.Controls.Add(this.pControlesClientes);
            this.Controls.Add(this.bBuscar);
            this.Controls.Add(this.bGuardar);
            this.Controls.Add(this.bActualizar);
            this.Controls.Add(this.bEliminar);
            this.Controls.Add(this.bAgregar);
            this.Controls.Add(this.bNuevo);
            this.Controls.Add(this.tbPuestoEnLaEmpresa);
            this.Controls.Add(this.tbEmpresa);
            this.Controls.Add(this.tbTelefono);
            this.Controls.Add(this.tbApellido);
            this.Controls.Add(this.tbNombreCliente);
            this.Controls.Add(this.tbClasificacion);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lTelefono);
            this.Controls.Add(this.lPuestoEnLaEmpresa);
            this.Controls.Add(this.lEmpresa);
            this.Controls.Add(this.lApellido);
            this.Controls.Add(this.lNombre);
            this.Controls.Add(this.tbCodigoCliente);
            this.Controls.Add(this.lcodigo);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FRMClientes";
            this.Text = "Registro de Clientes";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.pControlesClientes.ResumeLayout(false);
            this.pControlesClientes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lcodigo;
        private System.Windows.Forms.TextBox tbCodigoCliente;
        private System.Windows.Forms.Label lNombre;
        private System.Windows.Forms.Label lApellido;
        private System.Windows.Forms.Label lEmpresa;
        private System.Windows.Forms.Label lPuestoEnLaEmpresa;
        private System.Windows.Forms.Label lTelefono;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbClasificacion;
        private System.Windows.Forms.TextBox tbNombreCliente;
        private System.Windows.Forms.TextBox tbApellido;
        private System.Windows.Forms.TextBox tbTelefono;
        private System.Windows.Forms.TextBox tbEmpresa;
        private System.Windows.Forms.TextBox tbPuestoEnLaEmpresa;
        private System.Windows.Forms.Button bNuevo;
        private System.Windows.Forms.Button bAgregar;
        private System.Windows.Forms.Button bEliminar;
        private System.Windows.Forms.Button bActualizar;
        private System.Windows.Forms.Button bGuardar;
        private System.Windows.Forms.Button bBuscar;
        private System.Windows.Forms.Panel pControlesClientes;
        private System.Windows.Forms.Button bPrimero;
        private System.Windows.Forms.Button bSiguiente;
        private System.Windows.Forms.Button bUltimo;
        private System.Windows.Forms.Button bAnterior;
        private System.Windows.Forms.Label lde;
        private System.Windows.Forms.Label lRegistro;
        private System.Windows.Forms.TextBox tbUltimo;
        private System.Windows.Forms.TextBox tbPrimerRegistro;
    }
}