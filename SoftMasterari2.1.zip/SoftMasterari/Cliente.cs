﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftMaster
{
    internal class Cliente
    {
        private string codCliente;
        private string nombreCliente;
        private string apellido;
        private string empresa;
        private string puestoEmpresa;
        private string telefono; 
        private string clasificacion; //tecnico //general

        public string CodCliente { get => codCliente; set => codCliente = value; }
        public string NombreCliente { get => nombreCliente; set => nombreCliente = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public string Empresa { get => empresa; set => empresa = value; }
        public string PuestoEmpresa { get => puestoEmpresa; set => puestoEmpresa = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public string Clasificacion { get => clasificacion; set => clasificacion = value; }
    }
}
