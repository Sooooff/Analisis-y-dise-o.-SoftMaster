﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftMaster
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void miEstudiantes_Click(object sender, EventArgs e)
        {
            /*modulosPrin frm = new modulosPrin();
            frm.MdiParent = this;
            frm.Visible = true;*/
        }

        private void miMatricula_Click(object sender, EventArgs e)
        {

        }

        private void facturaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void miNuevaFactura_Click(object sender, EventArgs e)
        {

        }

        private void miEntradaDeMercancia_Click(object sender, EventArgs e)
        {
            FRMProducto EntradaDeMercancia = new FRMProducto();
            EntradaDeMercancia.Show();

            /*Form1 prueba = new Form1();
            prueba.MdiParent = this;
            prueba.Visible = true;*/
        }

        private void miAjustesSeInventario_Click(object sender, EventArgs e)
        {
            Form3 formAjustesInventario = new Form3();
            formAjustesInventario.Show();
        }

        // ...

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FRMClientes frmCliente = FRMClientes.getInstance();
            frmCliente.MdiParent = this;
            frmCliente.Visible = true;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            
        }
    }
}
