﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftMaster
{
    internal class TCliente
    {
        private TCliente()
        {
            tabla = new List<Cliente>();
            actual = -1;
        }

        private static TCliente instancia;
        private int actual;

        public static TCliente getInstancia()
        {
            if (instancia == null)
            {
                instancia = new TCliente();
            }
            return instancia;
        }

        private List<Cliente> tabla = new List<Cliente>();

        public int Actual { get => actual; set => actual = value; }

        public int guardar()
        {
            try
            {
                string temporal = "Temporal.bin", permanente = "Clientes.bin";
                using (var stream = File.Open(temporal, FileMode.Create, FileAccess.Write))
                {
                    using (var writer = new BinaryWriter(stream, Encoding.UTF8, false))
                    {
                        foreach (Cliente est in tabla)
                        {
                            writer.Write(est.CodCliente);
                            writer.Write(est.NombreCliente);
                            writer.Write(est.Apellido);
                            writer.Write(est.Empresa);
                            writer.Write(est.PuestoEmpresa);
                            writer.Write(est.Telefono);
                            writer.Write(est.Clasificacion);

                        }
                    }
                }
                File.Delete(permanente);
                File.Move(temporal, permanente);
                return 1;
            }
            catch (Exception e)
            {
                return 0;
            }
        }

        public bool verificarExistencia(string codCliente)
        {
            foreach (Cliente e in this.tabla)
            {
                if (e.CodCliente.Equals(codCliente))
                {
                    return true;
                }
            }
            return false;
        }

        public void agregarCliente(Cliente e)
        {
            this.tabla.Add(e);
            actual = this.tabla.Count - 1;
        }

        public bool verificarVacio()
        {
            if (!this.tabla.Any()) return true; else return false;
        }

        public int buscarRegistro(string cod)
        {
            foreach (Cliente e in this.tabla)
            {
                if (e.CodCliente.Equals(cod))
                {
                    return this.tabla.IndexOf(e);
                }
            }
            return -1;
        }

        public int cantidadRegistros()
        {
            return this.tabla.Count;
        }

        public void eliminarRegistro(int index)
        {
            this.tabla.RemoveAt(index);
        }

        public Cliente devolverPrimero()
        {
            if (this.actual == -1) return null;
            else
            {
                this.actual = 0;
                return this.tabla[actual];
            }

        }

        public Cliente buscarRegistro(int index)
        {
            return this.tabla[index];
        }

        public Cliente buscarClientePorCodigo(string codigo)
        {
            return tabla.FirstOrDefault(cli => cli.CodCliente == codigo);
        }

    }
}
