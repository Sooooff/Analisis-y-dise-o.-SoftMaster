﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftMaster
{
    internal class Factura
    {
        private int idFactura;
        private int cantidadProductoFactura;
        private int Iva;
        private int subtotal;
        private int totalFactura;
        private int metodoDePago;
        private DateTime fechaFactura;
        

        public int IdFactura { get => idFactura; set => idFactura = value; }
        public int CantidadProductoFactura { get => cantidadProductoFactura; set => cantidadProductoFactura = value; }
        public int Iva1 { get => Iva; set => Iva = value; }
        public int Subtotal { get => subtotal; set => subtotal = value; }
        public int TotalFactura { get => totalFactura; set => totalFactura = value; }
        public int MetodoDePago { get => metodoDePago; set => metodoDePago = value; }
        public DateTime FechaFactura { get => fechaFactura; set => fechaFactura = value; }
    }
}
