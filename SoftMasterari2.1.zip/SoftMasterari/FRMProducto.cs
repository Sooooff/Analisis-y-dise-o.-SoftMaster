﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftMaster
{
    public partial class FRMProducto : Form
    {
        private TProducto tablaProduc = TProducto.getInstancia();
        private static FRMProducto instance;
        public FRMProducto()
        {
            InitializeComponent();
        }
        public static FRMProducto getInstance()
        {
            if (instance == null || instance.IsDisposed)
                instance = new FRMProducto();
            return instance;
        }
        private void mostrarProd(Productos prod)
        {
            if (prod != null)
            {
                this.tbCodigoProducto.Text = prod.CodProducto;
                this.tbNombreProducto.Text = prod.NombreProducto;
                this.tbDescripcionProducto.Text = prod.Descripcion;
                this.tbCategoria.Text = prod.Categoria;
                this.tbPrecioDeVenta.Text = prod.PrecioVenta.ToString();
                this.tbPrecioDeCompra.Text = prod.PrecioCosto.ToString();
                this.tbProveedor.Text = prod.Proveedor;
                this.tbExistencias.Text = prod.Existencia.ToString();
            }
            else
            {
                this.tbCodigoProducto.Text = "";
                this.tbNombreProducto.Text = "";
                this.tbDescripcionProducto.Text = "";
                this.tbCategoria.Text = "";
                this.tbPrecioDeVenta.Text = "";
                this.tbPrecioDeCompra.Text = "";
                this.tbProveedor.Text = "";
                this.tbExistencias.Text = "";
                MessageBox.Show("No hay registro a mostrar",
                    "Registro de productos", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            this.actualizarPanelNavegacionProd();
        }
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void bNuevoProducto_Click(object sender, EventArgs e)
        {
            this.tbCodigoProducto.Enabled = true;
            this.tbCodigoProducto.Text = "";
            this.tbNombreProducto.Text = "";
            this.tbDescripcionProducto.Text = "";
            this.tbCategoria.Text = "";
            this.tbPrecioDeVenta.Text = "";
            this.tbPrecioDeCompra.Text = "";
            this.tbProveedor.Text = "";
            this.tbExistencias.Text = "";
        }

        private void bAgregarProducto_Click(object sender, EventArgs e)
        {
            if (tablaProduc.verificarExistenciaProd(this.tbCodigoProducto.Text) == false)
            {
                Productos prod = new Productos();

                prod.CodProducto = this.tbCodigoProducto.Text;
                prod.NombreProducto = this.tbNombreProducto.Text;
                prod.Descripcion = this.tbDescripcionProducto.Text;
                prod.Categoria = this.tbCategoria.Text;
                prod.PrecioVenta = int.Parse(this.tbPrecioDeVenta.Text);
                prod.PrecioCosto = int.Parse(this.tbPrecioDeCompra.Text);
                prod.Proveedor = this.tbProveedor.Text;
                prod.Existencia = int.Parse(this.tbExistencias.Text);
                tablaProduc.agregarProducto(prod);
                this.actualizarPanelNavegacionProd();
            }
            else
            {
                MessageBox.Show("Ya existe un producto con el Codigo indicado", "Registro de productos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void actualizarPanelNavegacionProd()
        {
            this.tbCodigoProducto.Enabled = false;
            this.tbPrimerRegistroProd.Enabled = false;
            this.tbUltimoProd.Enabled = false;
            if (tablaProduc.verificarVacioProd() == true)
                this.tbPrimerRegistroProd.Text = "0";
            else
                this.tbPrimerRegistroProd.Text = tablaProduc.buscarRegistroProd(this.tbCodigoProducto.Text + 1).ToString();
            this.tbUltimoProd.Text = tablaProduc.cantidadRegistrosProd().ToString();

        }

        private void bEliminarProducto_Click(object sender, EventArgs e)
        {
            int resp;
            if (this.tbCodigoProducto.Text != "")
            {
                resp = (int)MessageBox.Show("¿Esta seguro que desea eliminar el registro?",
                    "Registro de clientes",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (resp == 6)
                {
                    int index = tablaProduc.buscarRegistroProd(this.tbCodigoProducto.Text);
                    tablaProduc.eliminarRegistroProd(index);
                    if (tablaProduc.cantidadRegistrosProd() >= 1)
                    {
                        mostrarProd(tablaProduc.devolverPrimeroProd());
                    }
                    else
                    {
                        this.tbCodigoProducto.Text = "";
                        this.tbNombreProducto.Text = "";
                        this.tbDescripcionProducto.Text = "";
                        this.tbCategoria.Text = "";
                        this.tbPrecioDeVenta.Text = "";
                        this.tbPrecioDeCompra.Text = "";
                        this.tbProveedor.Text = "";
                        this.tbExistencias.Text = "";
                        mostrarProd(null);
                    }
                }
            }
        }

        private void bActualizarProducto_Click(object sender, EventArgs e)
        {
            int resp;
            if (this.tbCodigoProducto.Text != "")
            {
                resp = (int)MessageBox.Show("¿Esta seguro que desea actualizar el producto?",
                    "Registro de productos",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (resp == 6)
                {
                    int index = tablaProduc.buscarRegistroProd(this.tbCodigoProducto.Text);
                    Productos prod = tablaProduc.getTabla()[index];
                    prod.CodProducto = this.tbCodigoProducto.Text;
                    prod.NombreProducto = this.tbNombreProducto.Text;
                    prod.Descripcion = this.tbDescripcionProducto.Text;
                    prod.Categoria = this.tbCategoria.Text;
                    prod.PrecioVenta = int.Parse(this.tbPrecioDeVenta.Text);
                    prod.PrecioCosto = int.Parse(this.tbPrecioDeCompra.Text);
                    prod.Proveedor = this.tbProveedor.Text;
                    prod.Existencia = int.Parse(this.tbExistencias.Text);
                }
            }
        }

        private void bGuardarProducto_Click(object sender, EventArgs e)
        {
            int success;
            int resp = (int)MessageBox.Show("Esta seguro que desea guardar los datos permanentemente?",
                   "Registro de productos",
                   MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resp == 6)
            {
                success = tablaProduc.guardarProd();
                if (success != 0)
                {
                    MessageBox.Show("los datos se guardaron exitosamente", "registro del producto", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    MessageBox.Show("Error al guardar los datos", "registro del producto", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void bBuscar_Click(object sender, EventArgs e)
        {
            string codigo = this.tbCodigoProducto.Text;

            if (!string.IsNullOrEmpty(codigo))
            {
                buscarProducto(codigo);
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un código para buscar.",
                    "Búsqueda de clientes",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }
        private void buscarProducto(string codigo)
        {
            Productos prod = tablaProduc.buscarProductoPorCodigo(codigo);
            if (prod != null)
            {
                mostrarProd(prod);
            }
            else
            {
                MessageBox.Show("No se encontró un cliente con el código proporcionado.",
                    "Búsqueda de clientes",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void bPrimeroProd_Click(object sender, EventArgs e)
        {
            this.mostrarProd(this.tablaProduc.devolverPrimeroProd());
        }

        private void bAnteriorProd_Click(object sender, EventArgs e)
        {
            Productos prod = this.tablaProduc.devolverAnteriorProd();
            mostrarProd(prod);
        }

        private void bSiguienteProd_Click(object sender, EventArgs e)
        {
            Productos prod = this.tablaProduc.devolverSiguienteProd();
            if (prod == null)
                prod = this.tablaProduc.devolverPrimeroProd();
            mostrarProd(prod);
        }

        private void bUltimoProd_Click(object sender, EventArgs e)
        {
            this.mostrarProd(this.tablaProduc.devolverUltimoProd());
        }
    }
}
