﻿namespace SoftMaster
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.miArchivo = new System.Windows.Forms.ToolStripMenuItem();
            this.miGuardar = new System.Windows.Forms.ToolStripMenuItem();
            this.miSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.facturaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miNuevaFactura = new System.Windows.Forms.ToolStripMenuItem();
            this.miFacturasGeneradas = new System.Windows.Forms.ToolStripMenuItem();
            this.miInventario = new System.Windows.Forms.ToolStripMenuItem();
            this.miEntradaDeMercancia = new System.Windows.Forms.ToolStripMenuItem();
            this.miAjustesSeInventario = new System.Windows.Forms.ToolStripMenuItem();
            this.miMatricula = new System.Windows.Forms.ToolStripMenuItem();
            this.miReporteSemanal = new System.Windows.Forms.ToolStripMenuItem();
            this.miRerporteMensual = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrarClienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miInformacionDeContacto = new System.Windows.Forms.ToolStripMenuItem();
            this.miAyuda = new System.Windows.Forms.ToolStripMenuItem();
            this.miAcercade = new System.Windows.Forms.ToolStripMenuItem();
            this.miFAQ = new System.Windows.Forms.ToolStripMenuItem();
            this.catalogoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miArchivo,
            this.catalogoToolStripMenuItem,
            this.facturaToolStripMenuItem,
            this.miInventario,
            this.miMatricula,
            this.clientesToolStripMenuItem,
            this.miAyuda});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // miArchivo
            // 
            this.miArchivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miGuardar,
            this.miSalir});
            this.miArchivo.Name = "miArchivo";
            this.miArchivo.Size = new System.Drawing.Size(73, 24);
            this.miArchivo.Text = "Archivo";
            // 
            // miGuardar
            // 
            this.miGuardar.Name = "miGuardar";
            this.miGuardar.Size = new System.Drawing.Size(145, 26);
            this.miGuardar.Text = "Guardar";
            // 
            // miSalir
            // 
            this.miSalir.Name = "miSalir";
            this.miSalir.Size = new System.Drawing.Size(145, 26);
            this.miSalir.Text = "Salir";
            // 
            // facturaToolStripMenuItem
            // 
            this.facturaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miNuevaFactura,
            this.miFacturasGeneradas});
            this.facturaToolStripMenuItem.Name = "facturaToolStripMenuItem";
            this.facturaToolStripMenuItem.Size = new System.Drawing.Size(70, 24);
            this.facturaToolStripMenuItem.Text = "Factura";
            this.facturaToolStripMenuItem.Click += new System.EventHandler(this.facturaToolStripMenuItem_Click);
            // 
            // miNuevaFactura
            // 
            this.miNuevaFactura.Name = "miNuevaFactura";
            this.miNuevaFactura.Size = new System.Drawing.Size(219, 26);
            this.miNuevaFactura.Text = "Nueva Factura";
            this.miNuevaFactura.Click += new System.EventHandler(this.miNuevaFactura_Click);
            // 
            // miFacturasGeneradas
            // 
            this.miFacturasGeneradas.Name = "miFacturasGeneradas";
            this.miFacturasGeneradas.Size = new System.Drawing.Size(219, 26);
            this.miFacturasGeneradas.Text = "Facturas Generadas";
            // 
            // miInventario
            // 
            this.miInventario.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miEntradaDeMercancia,
            this.miAjustesSeInventario});
            this.miInventario.Name = "miInventario";
            this.miInventario.Size = new System.Drawing.Size(89, 24);
            this.miInventario.Text = "Inventario";
            // 
            // miEntradaDeMercancia
            // 
            this.miEntradaDeMercancia.Name = "miEntradaDeMercancia";
            this.miEntradaDeMercancia.Size = new System.Drawing.Size(236, 26);
            this.miEntradaDeMercancia.Text = "Entrada de Mercancia";
            this.miEntradaDeMercancia.Click += new System.EventHandler(this.miEntradaDeMercancia_Click);
            // 
            // miAjustesSeInventario
            // 
            this.miAjustesSeInventario.Name = "miAjustesSeInventario";
            this.miAjustesSeInventario.Size = new System.Drawing.Size(236, 26);
            this.miAjustesSeInventario.Text = "Ajustes de inventario";
            this.miAjustesSeInventario.Click += new System.EventHandler(this.miAjustesSeInventario_Click);
            // 
            // miMatricula
            // 
            this.miMatricula.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miReporteSemanal,
            this.miRerporteMensual});
            this.miMatricula.Name = "miMatricula";
            this.miMatricula.Size = new System.Drawing.Size(82, 24);
            this.miMatricula.Text = "Reportes";
            this.miMatricula.Click += new System.EventHandler(this.miMatricula_Click);
            // 
            // miReporteSemanal
            // 
            this.miReporteSemanal.Name = "miReporteSemanal";
            this.miReporteSemanal.Size = new System.Drawing.Size(206, 26);
            this.miReporteSemanal.Text = "Reporte Semanal";
            // 
            // miRerporteMensual
            // 
            this.miRerporteMensual.Name = "miRerporteMensual";
            this.miRerporteMensual.Size = new System.Drawing.Size(206, 26);
            this.miRerporteMensual.Text = "Reporte Mensual";
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registrarClienteToolStripMenuItem,
            this.miInformacionDeContacto});
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(75, 24);
            this.clientesToolStripMenuItem.Text = "Clientes";
            // 
            // registrarClienteToolStripMenuItem
            // 
            this.registrarClienteToolStripMenuItem.Name = "registrarClienteToolStripMenuItem";
            this.registrarClienteToolStripMenuItem.Size = new System.Drawing.Size(255, 26);
            this.registrarClienteToolStripMenuItem.Text = "Registrar Cliente";
            // 
            // miInformacionDeContacto
            // 
            this.miInformacionDeContacto.Name = "miInformacionDeContacto";
            this.miInformacionDeContacto.Size = new System.Drawing.Size(255, 26);
            this.miInformacionDeContacto.Text = "Información de contacto";
            // 
            // miAyuda
            // 
            this.miAyuda.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miAcercade,
            this.miFAQ});
            this.miAyuda.Name = "miAyuda";
            this.miAyuda.Size = new System.Drawing.Size(65, 24);
            this.miAyuda.Text = "Ayuda";
            // 
            // miAcercade
            // 
            this.miAcercade.Name = "miAcercade";
            this.miAcercade.Size = new System.Drawing.Size(224, 26);
            this.miAcercade.Text = "Acerca de...";
            // 
            // miFAQ
            // 
            this.miFAQ.Name = "miFAQ";
            this.miFAQ.Size = new System.Drawing.Size(224, 26);
            this.miFAQ.Text = "FAQ";
            // 
            // catalogoToolStripMenuItem
            // 
            this.catalogoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.productosToolStripMenuItem,
            this.clienteToolStripMenuItem});
            this.catalogoToolStripMenuItem.Name = "catalogoToolStripMenuItem";
            this.catalogoToolStripMenuItem.Size = new System.Drawing.Size(84, 26);
            this.catalogoToolStripMenuItem.Text = "Catalogo";
            // 
            // productosToolStripMenuItem
            // 
            this.productosToolStripMenuItem.Name = "productosToolStripMenuItem";
            this.productosToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.productosToolStripMenuItem.Text = "Productos";
            // 
            // clienteToolStripMenuItem
            // 
            this.clienteToolStripMenuItem.Name = "clienteToolStripMenuItem";
            this.clienteToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.clienteToolStripMenuItem.Text = "Cliente";
            this.clienteToolStripMenuItem.Click += new System.EventHandler(this.clienteToolStripMenuItem_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form4";
            this.Text = "COMPUTEC | Sistema de Facturación e Inventario";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form4_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem miArchivo;
        private System.Windows.Forms.ToolStripMenuItem miGuardar;
        private System.Windows.Forms.ToolStripMenuItem miSalir;
        private System.Windows.Forms.ToolStripMenuItem miInventario;
        private System.Windows.Forms.ToolStripMenuItem miEntradaDeMercancia;
        private System.Windows.Forms.ToolStripMenuItem miAjustesSeInventario;
        private System.Windows.Forms.ToolStripMenuItem miMatricula;
        private System.Windows.Forms.ToolStripMenuItem miAyuda;
        private System.Windows.Forms.ToolStripMenuItem miAcercade;
        private System.Windows.Forms.ToolStripMenuItem facturaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miReporteSemanal;
        private System.Windows.Forms.ToolStripMenuItem miRerporteMensual;
        private System.Windows.Forms.ToolStripMenuItem miNuevaFactura;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrarClienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miFAQ;
        private System.Windows.Forms.ToolStripMenuItem miInformacionDeContacto;
        private System.Windows.Forms.ToolStripMenuItem miFacturasGeneradas;
        private System.Windows.Forms.ToolStripMenuItem catalogoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clienteToolStripMenuItem;
    }
}