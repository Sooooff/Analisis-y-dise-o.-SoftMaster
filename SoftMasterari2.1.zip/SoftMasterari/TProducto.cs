﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SoftMaster
{
    internal class TProducto
    {
        private static TProducto instancia;
        private List<Productos> tabla;
        private int actual;

        public int Actual { get => actual; set => actual = value; }
        private TProducto()
        {
            tabla = new List<Productos>();
            actual = -1;
        }
        public static TProducto getInstancia()
        {
            if (instancia == null)
            {
                instancia = new TProducto();
            }
            return instancia;
        }
       
        public List<Productos> getTabla() 
        {
            return this.tabla;
        }
        public int guardarProd()
        {
            try
            {
                string temporal = "Temporal.bin", permanente = "Clientes.bin";
                using (var stream = File.Open(temporal, FileMode.Create, FileAccess.Write))
                {
                    using (var writer = new BinaryWriter(stream, Encoding.UTF8, false))
                    {
                        foreach (Productos est in tabla)
                        {
                            writer.Write(est.CodProducto);
                            writer.Write(est.NombreProducto);
                            writer.Write(est.Descripcion);
                            writer.Write(est.Categoria);
                            writer.Write(est.PrecioVenta);
                            writer.Write(est.PrecioCosto);
                            writer.Write(est.Proveedor);
                            writer.Write(est.Existencia);

                        }
                    }
                }
                File.Delete(permanente);
                File.Move(temporal, permanente);
                return 1;
            }
            catch (Exception e)
            {
                return 0;
            }
        }
        public void agregarProducto(Productos e)
        {
            this.tabla.Add(e);
            actual = this.tabla.Count - 1;
        }
      
        public int buscarRegistroProd(string cod)
        {
            foreach (Productos e in this.tabla)
            {
                if (e.CodProducto.Equals(cod))
                {
                    return this.tabla.IndexOf(e);
                }
            }
            return -1;
        }
  
        public bool verificarVacioProd()
        {
            if (!this.tabla.Any()) return true; else return false;
        }
 
        public int cantidadRegistrosProd()
        {
            return this.tabla.Count;
        }

        public bool verificarExistenciaProd(string codProducto)
        {
            foreach (Productos e in this.tabla)
            {
                if (e.CodProducto.Equals(codProducto))
                {
                    return true;
                }
            }
            return false;
        }
        public void eliminarRegistroProd(int index)
        {
            this.tabla.RemoveAt(index);
        }
        public Productos devolverPrimeroProd()
        {
            if (this.actual == -1) return null;
            else
            {
                this.actual = 0;
                return this.tabla[actual];
            }

        }
        public Productos devolverUltimoProd()
        {
            if (this.actual == -1) return null;
            else
            {
                this.actual = this.tabla.Count() - 1;
                return this.tabla[actual];
            }
        }

        public Productos devolverSiguienteProd()
        {
            if (actual != -1)
            {
                if (actual + 1 < this.tabla.Count)
                {
                    actual++;
                    return this.tabla[actual];
                }
            }
            return null;
        }

        public Productos devolverAnteriorProd()
        {
            if (actual != -1)
            {
                if (actual - 1 >= 0)
                {
                    actual--;
                    return this.tabla[actual];
                }
            }
            return null;
        }
        public Productos buscarProductoPorCodigo(string codigo)
        {
            return tabla.FirstOrDefault(prod => prod.CodProducto == codigo);
        }
    }
}
