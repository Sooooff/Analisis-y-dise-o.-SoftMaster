﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftMaster
{
    internal class Productos
    {
        private string codProducto;
        private string nombreProducto;
        
        private string descripcion;
        private string categoria;
      
        private int precioVenta;
        private int precioCosto;
        private string proveedor;
        private int existencia; 

        public string CodProducto { get => codProducto; set => codProducto = value; }
        public string NombreProducto { get => nombreProducto; set => nombreProducto = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
        public string Categoria { get => categoria; set => categoria = value; }
      
        public int PrecioVenta { get => precioVenta; set => precioVenta = value; }
        public int PrecioCosto { get => precioCosto; set => precioCosto = value; }
        public string Proveedor { get => proveedor; set => proveedor = value; }
        public int Existencia { get => existencia; set => existencia = value; }




    }
}
